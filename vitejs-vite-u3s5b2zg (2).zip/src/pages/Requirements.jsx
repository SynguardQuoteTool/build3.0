// src/pages/Requirements.jsx
import React, { useState, useEffect, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQuotes } from '../context/QuotesContext';
import { useProducts } from '../context/ProductsContext';
import { useQuickConfig } from '../context/QuickConfigContext';
import SoftwareModal from './SoftwareModal';
import ControllerSelectionModal from './ControllerSelectionModal';
import ConfigModal from './ConfigModal';
import './QuickConfig.css';
import {
    getCurrencyCode,
    getCurrencySymbol,
    getPriceForCurrency,
} from '../utils/currencyUtils';

// Constants
const CONTROLLERS = [
    {
        model: 'SynApp',
        isSiteController: true,
        connectionToServer: 'IP',
        quoteHardware: 'S03835',
        quoteModelNameHW: 'SynApp-DIN-HW',
        baseDoors: 1,
        baseWiegandReaders: 1,
        baseOSDPReaders: 2,
        wiegandInOutDoors: 0,
        osdpInOutDoors: 1,
        baseInputs: 3,
        baseOutputs: 2,
        maxDoorControllers: 32,
        maxReaders: 256,
        requiresSynApp: true,
    },
    {
        model: 'SynOne',
        isSiteController: true,
        connectionToServer: 'IP',
        quoteHardware: 'S12345',
        quoteModelNameHW: 'Synone-HW',
        baseDoors: 1,
        baseWiegandReaders: 1,
        baseOSDPReaders: 2,
        wiegandInOutDoors: 0,
        osdpInOutDoors: 1,
        baseInputs: 3,
        baseOutputs: 2,
        maxDoorControllers: 0,
        requiresSynApp: false,
    },
    {
        model: 'SynConSC',
        isSiteController: false,
        connectsToSiteController: true,
        connectsRS485: true,
        quoteHardware: 'S03850',
        quoteModelNameHW: 'SynConSC-HW',
        baseDoors: 2,
        baseWiegandReaders: 2,
        baseOSDPReaders: 4,
        wiegandInOutDoors: 1,
        osdpInOutDoors: 2,
        baseInputs: 6,
        baseOutputs: 2,
        requiresSynApp: true,
    },
    {
        model: 'SynConDuoDuo',
        isSiteController: false,
        connectsToSiteController: true,
        connectsRS485: true,
        quoteHardware: 'S03846',
        quoteModelNameHW: 'SynCon-HW',
        baseDoors: 4,
        baseWiegandReaders: 0,
        baseOSDPReaders: 8,
        wiegandInOutDoors: 0,
        osdpInOutDoors: 4,
        baseInputs: 6,
        baseOutputs: 4,
        requiresSynApp: true,
    },
    {
        model: 'SynConEvo',
        isSiteController: false,
        connectsToSiteController: true,
        connectsRS485: true,
        connectsIP: true,
        quoteHardware: 'S03855',
        quoteModelNameHW: 'SynConEvo-DIN-HW',
        baseDoors: 8,
        baseWiegandReaders: 0,
        baseOSDPReaders: 16,
        wiegandInOutDoors: 0,
        osdpInOutDoors: 8,
        baseInputs: 20,
        baseOutputs: 8,
        requiresSynApp: true,
    },
    {
        model: 'SynIO',
        isSiteController: false,
        connectsToSiteController: true,
        connectsRS485: true,
        quoteHardware: 'S03869',
        quoteModelNameHW: 'SynIO-DIN-HW',
        baseDoors: 0,
        baseWiegandReaders: 0,
        baseOSDPReaders: 0,
        baseInputs: 16,
        baseOutputs: 16,
        requiresSynApp: true,
    },
];
const SOFTWARE_PARTS = {};
const SYNAPP_MAX_DOOR_CONTROLLERS = 32;
const SYNAPP_MAX_READERS = 128;

const getInitialCtrlState = () =>
    CONTROLLERS.reduce((acc, ctrl) => {
        acc[ctrl.model] = 0;
        return acc;
    }, {});
const findControllerInfo = (modelName) =>
    CONTROLLERS.find((c) => c.model === modelName);
const findSoftwareInfo = (key) => SOFTWARE_PARTS[key];


export default function Requirements() {
    const { configState, updateConfigState, resetConfigState } = useQuickConfig();
    const { 
        name,
        systemType,
        date,
        protocol,
        commsType,
        deployment,
        targetDoorsPerController,
        allowFlexibility,  // Add this line
        excludeSynAppDoor,
        doors,
        readersIn,
        readersOut,
        reqInputs,
        reqOutputs,
        systemUsers,
        softwareSelections,
        softwareQuoteItems,
        client,
        notes,
    } = configState;
    const { addQuote, currentUser } = useQuotes();
    const { products, loading: productsLoading } = useProducts();
    const navigate = useNavigate();
    const { state } = useLocation();
    const [ctrls, setCtrls] = useState(getInitialCtrlState());
    const [showSoftwareModal, setShowSoftwareModal] = useState(false);
    const [showControllerModal, setShowControllerModal] = useState(false);
    const [showConfigModal, setShowConfigModal] = useState(false);
    const [availableTargetCapacities, setAvailableTargetCapacities] = useState([]);

    // Log configState changes
    useEffect(() => {
        console.log("Requirements: configState updated", configState);
    }, [configState]);

    useEffect(() => {
        // This effect runs only when the component mounts
        if (state) {
            // If state was passed from navigation, use it
            updateConfigState({
                name: state.name || "",
                systemType: state.systemType || "",
                date: state.date || new Date().toISOString().slice(0, 10),
                protocol: state.protocol || "",
                commsType: state.doorComms || "",
                deployment: state.deployment || "In Only",
                targetDoorsPerController: state.targetDoorsPerController || "",
                excludeSynAppDoor: state.excludeSynAppDoor || false,
            });
        } else {
            // If no state was passed, ensure we're using reset values
            // This is an additional safety check
            resetConfigState();
        }
    }, []); // Empty dependency array ensures this runs only once on mount

    const HARDWARE_SOFTWARE_MAP = {
        "SynApp": { onPremSW: { articleNumber: "S03836", model: "SynApp-DIN-SW" }, cloudSW: { articleNumber: "S03836", model: "SynApp-DIN-SW" } },
        "SynConSC": { onPremSW: { articleNumber: "S03847", model: "SynCon-SW" }, cloudSW: { articleNumber: "S03847H", model: "H-SynCon-SW" } },
        "SynConDuoDuo": { onPremSW: { articleNumber: "S03847", model: "SynCon-SW" }, cloudSW: { articleNumber: "S03847H", model: "H-SynCon-SW" } },
        "SynConEvo": { onPremSW: { articleNumber: "S03852", model: "SynConEvo-SW" }, cloudSW: { articleNumber: "S03852H", model: "H-SynConEvo-SW" } },
        "SynIO": { onPremSW: { articleNumber: "S03872", model: "SynIO-DIN-SW" }, cloudSW: { articleNumber: "S03872H", model: "SynIO-DIN-SW" } }
        //add SynOneSW rule//
    };
    
    const getCurrentSystemCurrency = () => {
       try {
          const settings = localStorage.getItem('systemSettings');
          if (settings) {
            const parsed = JSON.parse(settings);
            return {
              symbol: parsed.currency || '£',
              code: parsed.currency === '€' ? 'EUR' : (parsed.currency === '$' ? 'USD' : 'GBP')
            };
          }
        } catch (e) {
          // ignore
        }
        return { symbol: '£', code: 'GBP' };
    };

    const handleNumberChange = (fieldName) => (e) => {
        const value = Math.max(0, parseInt(e.target.value, 10) || 0);
        console.log("Requirements: handleNumberChange", { fieldName, value });
        updateConfigState({ [fieldName]: value });
    };

    const handleExcludeSynAppChange = (e) => {
        const checked = e.target.checked;
        console.log("Requirements: handleExcludeSynAppChange", { excludeSynAppDoor: checked });
        updateConfigState({ excludeSynAppDoor: checked });
    };

    const handleSoftwareSave = (selectedItems) => {
        console.log("Requirements: handleSoftwareSave", { selectedItems });
        
        // Store selections for state tracking
        const selections = {};
        selectedItems.forEach((item) => {
            selections[item.name] = { enabled: true, quantity: item.qty || 1 };
        });
        
        // Create quote items from the selections
        const softwareQuoteItems = selectedItems.map(item => {
            const productDetail = products.find(p => p.articleNumber === item.articleNumber);
            
            return {
                articleNumber: item.articleNumber,
                model: item.model,
                description: item.description || productDetail?.descriptionEN || "Software Component",
                method: productDetail?.method || (systemType === 'Cloud' ? 'Recurring' : 'Upfront'),
                msrpGBP: productDetail?.msrpGBP ?? 0,
                msrp: productDetail?.msrpGBP ?? 0,
                discountStandard: productDetail?.discountStandard ?? 0,
                qty: item.qty || 1,
                costType: (systemType === 'Cloud' || (productDetail?.type?.toLowerCase().includes('recurring'))) 
                        ? 'Monthly' : 'One-Off',
                smc: productDetail?.smc ?? 0,
            };
        });
        
        // Update config state with both the selections and the quote items
        updateConfigState({
            softwareSelections: selections,
            softwareQuoteItems: softwareQuoteItems
        });
        
        setShowSoftwareModal(false);
    };

    const handleControllerSave = (selections) => {
        console.log("Requirements: handleControllerSave", { selections });
        setCtrls(selections);
        setShowControllerModal(false);
    };

    const handleConfigSave = (config) => {
        console.log("=== handleConfigSave called ===");
        console.log("Requirements: handleConfigSave", { config });
        console.log("Previous configState:", { protocol, commsType, deployment, targetDoorsPerController, allowFlexibility });
        
        const updatedConfig = {
            protocol: config.protocol,
            commsType: config.doorComms,
            deployment: config.deployment === "In Only" ? "In" : "In & Out",
            targetDoorsPerController: config.targetDoorsPerController,
            allowFlexibility: config.allowFlexibility || false,
        };
        console.log("Updating configState with:", updatedConfig);
        
        // Force complete reset before update
        console.log("=== FORCING COMPLETE RESET ===");
        setCtrls(getInitialCtrlState());
        
        // Update config state
        updateConfigState(updatedConfig);
        setShowConfigModal(false);
        
        console.log("=== handleConfigSave completed ===");
    };

    // Controller calculation logic
    const availableControllerData = useMemo(() => {
        console.log("=== availableControllerData recalculating ===");
        console.log("Inputs:", { protocol, deployment, commsType });
        console.log("Deployment raw value:", deployment);
        
        if (!protocol || !deployment || !commsType) {
            console.log("Missing required inputs, returning empty array");
            return [];
        }
        
        let mdls = [];
        let caps = {};
        const deploy = deployment === "In Only" ? "In" : "In & Out";
        console.log("Deployment mapped to:", deploy);

        if (protocol === "Wiegand") {
            console.log("Processing Wiegand protocol");
            if (deploy === "In") {
                console.log("Wiegand + In Only path");
                if (commsType === "IP") {
                    console.log("Wiegand + IP + In Only");
                    mdls = ["SynApp", "SynOne"];
                    caps = {
                        SynApp: { doors: 1, readers: 1, wiegand: 1, requiresSynApp: true },
                        SynOne: { doors: 1, readers: 1, wiegand: 1, requiresSynApp: false },
                    };
                } else if (commsType === "RS-485") {
                    console.log("Wiegand + RS-485 + In Only - SHOULD ALLOW MULTI-DOOR CONTROLLERS");
                    mdls = ["SynApp", "SynConSC", "SynConDuoDuo"];
                    caps = {
                        SynApp: { doors: 1, readers: 1, wiegand: 1, requiresSynApp: true },
                        SynConSC: { doors: 2, readers: 2, wiegand: 2, requiresSynApp: true },
                        SynConDuoDuo: { doors: 4, readers: 4, wiegand: 4, requiresSynApp: true },
                    };
                    console.log("SynConSC should have 2 doors capacity:", caps.SynConSC);
                }
            } else if (deploy === "In & Out") {
                console.log("Wiegand + In & Out path");
                // Wiegand + In & Out is only possible with RS-485 and SynConSC
                if (commsType === "RS-485") {
                    console.log("Wiegand + RS-485 + In & Out - FORCING 1 DOOR PER CONTROLLER");
                    mdls = ["SynConSC"];
                    caps = {
                        // SynConSC with Wiegand In&Out: each controller handles 1 door (2 readers per door)
                        SynConSC: { doors: 1, readers: 2, wiegand: 2, requiresSynApp: true },
                    };
                    console.log("SynConSC should have 1 door capacity:", caps.SynConSC);
                }
                // Wiegand + IP + In&Out is not possible - no controllers available
            }
        } else if (protocol === "OSDP") {
            if (deploy === "In") {
                if (commsType === "IP") {
                    mdls = ["SynConEvo", "SynOne"];
                    caps = {
                        SynConEvo: { doors: 8, readers: 16, wiegand: 0, requiresSynApp: true },
                        SynOne: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: false },
                    };
                } else if (commsType === "RS-485") {
                    mdls = ["SynApp", "SynConSC", "SynConDuoDuo", "SynConEvo"];
                    caps = {
                        SynApp: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: true },
                        SynConSC: { doors: 2, readers: 4, wiegand: 0, requiresSynApp: true },
                        SynConDuoDuo: { doors: 4, readers: 8, wiegand: 0, requiresSynApp: true },
                        SynConEvo: { doors: 8, readers: 16, wiegand: 0, requiresSynApp: true },
                    };
                } else if (commsType === "Mixed (RS-485 & IP)") {
                    mdls = ["SynApp", "SynConSC", "SynConDuoDuo", "SynConEvo", "SynOne"];
                    caps = {
                        SynApp: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: true },
                        SynConSC: { doors: 2, readers: 4, wiegand: 0, requiresSynApp: true },
                        SynConDuoDuo: { doors: 4, readers: 8, wiegand: 0, requiresSynApp: true },
                        SynConEvo: { doors: 8, readers: 16, wiegand: 0, requiresSynApp: true },
                        SynOne: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: false },
                    };
                }
            } else if (deploy === "In & Out") {
                if (commsType === "IP") {
                    mdls = ["SynConEvo", "SynOne"];
                    caps = {
                        SynConEvo: { doors: 8, readers: 16, wiegand: 0, requiresSynApp: true },
                        SynOne: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: false },
                    };
                } else if (commsType === "RS-485") {
                    mdls = ["SynApp", "SynConSC", "SynConDuoDuo", "SynConEvo"];
                    caps = {
                        SynApp: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: true },
                        SynConSC: { doors: 2, readers: 4, wiegand: 0, requiresSynApp: true },
                        SynConDuoDuo: { doors: 4, readers: 8, wiegand: 0, requiresSynApp: true },
                        SynConEvo: { doors: 8, readers: 16, wiegand: 0, requiresSynApp: true },
                    };
                } else if (commsType === "Mixed (RS-485 & IP)") {
                    mdls = ["SynApp", "SynConSC", "SynConDuoDuo", "SynConEvo", "SynOne"];
                    caps = {
                        SynApp: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: true },
                        SynConSC: { doors: 2, readers: 4, wiegand: 0, requiresSynApp: true },
                        SynConDuoDuo: { doors: 4, readers: 8, wiegand: 0, requiresSynApp: true },
                        SynConEvo: { doors: 8, readers: 16, wiegand: 0, requiresSynApp: true },
                        SynOne: { doors: 1, readers: 2, wiegand: 0, requiresSynApp: false },
                    };
                }
            }
        }

        const result = mdls.map((m) => {
            const b = findControllerInfo(m);
            const e = caps[m] || {};
            const r = e.requiresSynApp !== false;
            const controllerData = {
                model: m,
                description: b?.description || "Unknown",
                effectiveDoors: e.doors ?? b?.baseDoors ?? 0,
                effectiveDoorsInOnly: e.doorsInOnly ?? e.doors ?? b?.baseDoors ?? 0,
                effectiveReaders: e.readers ?? (protocol === 'Wiegand' ? b?.baseWiegandReaders : b?.baseOSDPReaders) ?? 0,
                effectiveWiegand: e.wiegand ?? b?.baseWiegandReaders ?? 0,
                requiresSynAppInitially: r,
                quoteHardware: b?.quoteHardware,
            };
            console.log(`Controller ${m}:`, controllerData);
            return controllerData;
        }).filter((c) => !(protocol === "Wiegand" && c.model === "SynConEvo"));
        
        console.log("Final availableControllerData:", result);
        return result;
    }, [protocol, deployment, commsType]);

    // Add availableTargetCapacities computation
    useEffect(() => {
        const controllers = availableControllerData.filter(c => c.model !== 'SynApp' && c.model !== 'SynIO' && c.effectiveDoors > 0);
        const uniqueCapacities = [...new Set(controllers.map(c => c.effectiveDoors))].sort((a, b) => a - b);

        const capacitiesWithLabels = uniqueCapacities.map(capacity => ({
            value: capacity,
            label: `${capacity} Door${capacity !== 1 ? 's' : ''}`
        }));

        setAvailableTargetCapacities(capacitiesWithLabels);
        if (targetDoorsPerController && !uniqueCapacities.includes(parseInt(targetDoorsPerController))) {
            updateConfigState({ targetDoorsPerController: "" });
        }
    }, [availableControllerData, targetDoorsPerController, protocol, deployment, updateConfigState]);

    // Combined useEffect for readersIn and readersOut
    useEffect(() => {
        const updates = {};
        if (doors && readersIn !== doors) {
            updates.readersIn = doors;
        }
        if (readersOut > doors && readersOut !== doors) {
            updates.readersOut = doors;
        }
        if (Object.keys(updates).length > 0) {
            updateConfigState(updates);
        }
    }, [doors, readersIn, readersOut, updateConfigState]);

    useEffect(() => {
        console.log("=== Controller calculation useEffect triggered ===");
        console.log("Dependencies:", { 
            protocol, deployment, commsType, doors, targetDoorsPerController, allowFlexibility, excludeSynAppDoor,
            availableControllerDataLength: availableControllerData.length
        });
        
        if (
            protocol &&
            deployment &&
            commsType &&
            availableControllerData.length > 0
        ) {
            console.log("All dependencies satisfied, running calculation");
            console.log("Available controller data:", availableControllerData);
            
            const calcCtrls = calculateOptimizedControllers(
                commsType,
                protocol,
                deployment === "In Only" ? "In" : "In & Out",
                doors,
                readersIn,
                readersOut,
                targetDoorsPerController,
                allowFlexibility,
                reqInputs,
                reqOutputs,
                availableControllerData,
                excludeSynAppDoor
            );
            console.log("Calculated controllers result:", calcCtrls);
            setCtrls(calcCtrls);
        } else {
            console.log("Dependencies not satisfied, resetting controllers");
            console.log("Missing:", {
                protocol: !protocol,
                deployment: !deployment, 
                commsType: !commsType,
                availableControllerData: availableControllerData.length === 0
            });
            setCtrls(getInitialCtrlState());
        }
        console.log("=== Controller calculation useEffect completed ===");
    }, [
        protocol,
        deployment,
        commsType,
        doors,
        readersIn,
        readersOut,
        targetDoorsPerController,
        allowFlexibility,
        reqInputs,
        reqOutputs,
        excludeSynAppDoor,
        availableControllerData,
    ]);

    const totalReqReaders = useMemo(() => readersIn + readersOut, [readersIn, readersOut]);

    const { totalProvidedDoors, totalProvidedReaders, totalProvidedInputs, totalProvidedOutputs } = useMemo(() => {
        let d = 0,
            tR = 0,
            i = 0,
            o = 0;
        const deploy = deployment === "In Only" ? "In" : "In & Out";
        Object.entries(ctrls).forEach(([m, c]) => {
            if (c > 0) {
                const cd = availableControllerData.find((x) => x.model === m);
                const bi = findControllerInfo(m);
                const isEx = m === "SynApp" && excludeSynAppDoor;
                const drC = isEx ? 0 : (cd?.effectiveDoors ?? bi?.baseDoors ?? 0);
                const rdrC = isEx ? 0 : (cd?.effectiveReaders ?? (protocol === 'Wiegand' ? bi?.baseWiegandReaders : bi?.baseOSDPReaders) ?? 0);
                const iC = isEx ? 0 : (bi?.baseInputs ?? 0);
                const oC = isEx ? 0 : (bi?.baseOutputs ?? 0);
                
                // Special case: SynConSC with Wiegand In&Out
                if (m === "SynConSC" && protocol === "Wiegand" && deploy === "In & Out") {
                    // Each SynConSC handles 1 door (2 readers) in this mode
                    d += c * 1; // 1 door per controller
                    tR += c * 2; // 2 readers per controller
                } else {
                    d += c * drC;
                    tR += c * rdrC;
                }
                i += c * iC;
                o += c * oC;
            }
        });
        return {
            totalProvidedDoors: d,
            totalProvidedReaders: tR,
            totalProvidedInputs: i,
            totalProvidedOutputs: o,
        };
    }, [ctrls, availableControllerData, excludeSynAppDoor, protocol, deployment]);

    const calculatedQuoteItems = useMemo(() => {
        const systemCurrency = getCurrentSystemCurrency();
        const { symbol: currencySymbol, code: currencyCode } = systemCurrency;
        const items = [];

        if (productsLoading || !Array.isArray(products) || products.length === 0) {
            console.warn("Products data not available yet. Preview may be incomplete.");
            return [];
        }

        // Helper function to get price based on currency
        const getPriceFromProduct = (productDetail) => {
            if (!productDetail) return 0;
            
            switch (currencyCode) {
                case 'EUR':
                    return productDetail.msrpEUR || productDetail.mrspEUR || productDetail.msrpGBP || 0;
                case 'USD':
                    return productDetail.msrpUSD || productDetail.mrspUSD || productDetail.msrpGBP || 0;
                default: // GBP
                    return productDetail.msrpGBP || productDetail.mrspGBP || 0;
            }
        };
        
        // Add hardware controllers
        Object.entries(ctrls).forEach(([modelKey, qty]) => {
            if (qty > 0) {
                const controllerInfo = findControllerInfo(modelKey);
                if (!controllerInfo) return;
                const hardwareArticleNumber = controllerInfo.quoteHardware;
                if (!hardwareArticleNumber) return;
                
                const productDetail = products.find((p) => p.articleNumber === hardwareArticleNumber);
                const price = getPriceFromProduct(productDetail);

                items.push({
                    articleNumber: hardwareArticleNumber,
                    model: controllerInfo.quoteModelNameHW || modelKey,
                    description: productDetail?.descriptionEN || controllerInfo?.description || "Unknown Hardware",
                    method: productDetail?.method || "Upfront",
                    msrp: price,
                    msrpGBP: productDetail?.msrpGBP || 0, // Keep for compatibility
                    discountStandard: productDetail?.discountStandard ?? 0,
                    qty: qty,
                    costType: productDetail?.type?.toLowerCase().includes('recurring') ? "Monthly" : "One-Off",
                    smc: productDetail?.smc ?? 0,
                    currency: currencyCode,
                    currencySymbol: currencySymbol
                });
            }
        });

        // Track which software has been added to avoid duplicates
        const addedSoftware = new Set();

        // Add required software for hardware
        Object.entries(ctrls).forEach(([modelKey, qty]) => {
            if (qty > 0 && HARDWARE_SOFTWARE_MAP[modelKey]) {
                const hwSoftware = systemType === 'Cloud' 
                    ? HARDWARE_SOFTWARE_MAP[modelKey].cloudSW 
                    : HARDWARE_SOFTWARE_MAP[modelKey].onPremSW;
                
                // Skip if this software is already added
                if (addedSoftware.has(hwSoftware.articleNumber)) return;
                
                // Mark this software as added
                addedSoftware.add(hwSoftware.articleNumber);
                
                // Find product details
                const softwareProductDetail = products.find(p => p.articleNumber === hwSoftware.articleNumber);
                const price = getPriceFromProduct(softwareProductDetail);
                
                // Add software to items
                items.push({
                    articleNumber: hwSoftware.articleNumber,
                    model: hwSoftware.model,
                    description: softwareProductDetail?.descriptionEN || `${modelKey} Software License`,
                    method: softwareProductDetail?.method || (systemType === 'Cloud' ? 'Recurring' : 'Upfront'),
                    msrp: price,
                    msrpGBP: softwareProductDetail?.msrpGBP || 0, // Keep for compatibility
                    discountStandard: softwareProductDetail?.discountStandard ?? 0,
                    qty: qty, // One software license per hardware unit
                    costType: systemType === 'Cloud' ? 'Monthly' : 'One-Off',
                    smc: softwareProductDetail?.smc ?? 0,
                    currency: currencyCode,
                    currencySymbol: currencySymbol
                });
            }
        });

        // Add platform and user licenses
        if (systemType) {
            // Platform license
            const platformArticleNumber = systemType === 'Cloud' ? 'S00531H' : 'S00531';
            const platformProduct = products.find(p => p.articleNumber === platformArticleNumber);
            const platformPrice = getPriceFromProduct(platformProduct);
            
            if (platformProduct) {
                items.push({
                    articleNumber: platformArticleNumber,
                    model: systemType === 'Cloud' ? 'H-Synguard-Platform' : 'Synguard-Platform',
                    description: platformProduct.descriptionEN || `${systemType} Platform License`,
                    method: platformProduct.method || (systemType === 'Cloud' ? 'Recurring' : 'Upfront'),
                    msrp: platformPrice,
                    msrpGBP: platformProduct?.msrpGBP || 0, // Keep for compatibility
                    discountStandard: platformProduct.discountStandard ?? 0,
                    qty: 1,
                    costType: systemType === 'Cloud' ? 'Monthly' : 'One-Off',
                    smc: platformProduct.smc ?? 0,
                    currency: currencyCode,
                    currencySymbol: currencySymbol
                });
            } else {
                // Fallback if product not found
                console.warn(`Platform product with article number ${platformArticleNumber} not found`);
                items.push({
                    articleNumber: platformArticleNumber,
                    model: systemType === 'Cloud' ? 'H-Synguard-Platform' : 'Synguard-Platform',
                    description: `${systemType} Platform License`,
                    method: systemType === 'Cloud' ? 'Recurring' : 'Upfront',
                    msrp: 0,
                    msrpGBP: 0, // Keep for compatibility
                    discountStandard: 0,
                    qty: 1,
                    costType: systemType === 'Cloud' ? 'Monthly' : 'One-Off',
                    smc: 0,
                    currency: currencyCode,
                    currencySymbol: currencySymbol
                });
            }
            
            // User licenses (only if systemUsers > 0)
            if (systemUsers > 0) {
                const userLicenseArticleNumber = systemType === 'Cloud' ? 'S00524H' : 'S00524';
                const userLicenseProduct = products.find(p => p.articleNumber === userLicenseArticleNumber);
                const userPrice = getPriceFromProduct(userLicenseProduct);
                
                if (userLicenseProduct) {
                    items.push({
                        articleNumber: userLicenseArticleNumber,
                        model: systemType === 'Cloud' ? 'H-Synguard' : 'Synguard',
                        description: userLicenseProduct.descriptionEN || `${systemType} User License`,
                        method: userLicenseProduct.method || (systemType === 'Cloud' ? 'Recurring' : 'Upfront'),
                        msrpGBP: userLicenseProduct.msrpGBP ?? 0,
                        msrp: userPrice,
                        discountStandard: userLicenseProduct.discountStandard ?? 0,
                        qty: systemUsers,
                        costType: systemType === 'Cloud' ? 'Monthly' : 'One-Off',
                        smc: userLicenseProduct.smc ?? 0,
                        currency: currencyCode,
                        currencySymbol: currencySymbol
                    });
                } else {
                    // Fallback if product not found
                    console.warn(`User license product with article number ${userLicenseArticleNumber} not found`);
                    items.push({
                        articleNumber: userLicenseArticleNumber,
                        model: systemType === 'Cloud' ? 'H-Synguard' : 'Synguard',
                        description: `${systemType} User License`,
                        method: systemType === 'Cloud' ? 'Recurring' : 'Upfront',
                        msrp: 0,
                        msrpGBP: 0, // Keep for compatibility
                        discountStandard: 0,
                        qty: systemUsers,
                        costType: systemType === 'Cloud' ? 'Monthly' : 'One-Off',
                        smc: 0,
                        currency: currencyCode,
                        currencySymbol: currencySymbol
                    });
                }
            }
        }
        
        // Add software items from software modal
        if (softwareQuoteItems && Array.isArray(softwareQuoteItems)) {
            // Apply currency conversion to software items as well
            const convertedSoftwareItems = softwareQuoteItems.map(item => ({
                ...item,
                msrp: getPriceFromProduct(products.find(p => p.articleNumber === item.articleNumber)) || item.msrp || 0,
                currency: currencyCode,
                currencySymbol: currencySymbol
            }));
            items.push(...convertedSoftwareItems);
        }
        
        return items.sort((a, b) => {
            const mO = { 'Upfront': 1, 'Recurring': 2 };
            const mA = a.method || '';
            const mB = b.method || '';
            const mC = (mO[mA] || 3) - (mO[mB] || 3);
            if (mC !== 0) return mC;
            return (a.articleNumber || '').localeCompare(b.articleNumber || '');
        });
    }, [ctrls, systemType, systemUsers, excludeSynAppDoor, products, productsLoading, softwareQuoteItems]);

    // Updated calculateOptimizedControllers function with allowFlexibility parameter
    function calculateOptimizedControllers(comm, tech, deploy, requiredDoors, rIn, rOut, targetCapacityStr, allowFlexibilityFlag, requiredInputs, requiredOutputs, availableData, excludeSynAppDoorFlag) {
        console.log('--- calculateOptimizedControllers entered ---');
        console.log('Parameters:', { comm, tech, deploy, requiredDoors, rIn, rOut, targetCapacityStr, allowFlexibilityFlag });
        
        const C = getInitialCtrlState();
        let doorsToAllocate = requiredDoors;
        const initialSynAppRequiredByAnyComponent = availableData.some(c => c.requiresSynAppInitially);
        let isSynOneOnlyScenario = false;
        const synAppData = availableData.find(c => c.model === 'SynApp');
        
        // Step 1: Handle SynApp allocation
        if (initialSynAppRequiredByAnyComponent) {
            C.SynApp = 1;
            console.log('Adding SynApp: Required by components');
        } else {
            C.SynApp = (synAppData && synAppData.effectiveDoors > 0 && !excludeSynAppDoorFlag) ? 1 : 0;
            if (C.SynApp > 0) {
                console.log('Adding SynApp: For door control');
            }
        }
        
        // If SynApp is used for doors, subtract its capacity (but NOT for Wiegand In&Out)
        if (C.SynApp > 0 && synAppData && synAppData.effectiveDoors > 0 && doorsToAllocate > 0 && !excludeSynAppDoorFlag && !(tech === 'Wiegand' && deploy === 'In & Out')) {
            doorsToAllocate -= synAppData.effectiveDoors;
            doorsToAllocate = Math.max(0, doorsToAllocate);
            console.log(`SynApp door handling: ${synAppData.effectiveDoors} doors allocated, ${doorsToAllocate} remaining`);
        }
        
        // Step 2: Identify potential door controllers
        let potentialDoorControllers = availableData
            .filter(c => c.model !== 'SynApp' && c.model !== 'SynIO' && c.effectiveDoors > 0)
            .sort((a, b) => b.effectiveDoors - a.effectiveDoors); // Sort by capacity, highest first
        
        if (potentialDoorControllers.length === 0 && synAppData && synAppData.effectiveDoors > 0 && !excludeSynAppDoorFlag) {
            potentialDoorControllers = [synAppData];
            console.log('No door controllers available, using SynApp');
        }
        
        if (potentialDoorControllers.length === 0) {
            console.log('No door controllers available');
            finalizeSynAppCount(C, rIn + rOut, isSynOneOnlyScenario);
            calculateSynIO(C, requiredInputs, requiredOutputs, excludeSynAppDoorFlag);
            return C;
        }
        
        // Step 3: Handle special case - Wiegand + In & Out with SynConSC
        if (tech === 'Wiegand' && deploy === 'In & Out' && comm === 'RS-485') {
            console.log("USING SPECIAL CASE: Wiegand + In & Out + RS-485");
            const synConSC = potentialDoorControllers.find(c => c.model === 'SynConSC');
            if (synConSC && doorsToAllocate > 0) {
                // Each SynConSC handles 1 door (2 readers) in Wiegand In&Out mode
                C.SynConSC = doorsToAllocate;
                console.log(`Special case: Wiegand + In&Out + RS-485: Added ${doorsToAllocate} SynConSC controllers (1 per door)`);
                doorsToAllocate = 0;
            }
        }
        // Step 4: Target capacity handling with flexibility (for ALL other cases, including Wiegand In Only)
        else if (doorsToAllocate > 0) {
            console.log("NOT USING SPECIAL CASE - using normal multi-door logic");
            console.log("Current config:", { tech, deploy, comm });
            console.log("Available controllers for normal logic:", potentialDoorControllers.map(c => `${c.model}(${c.effectiveDoors} doors)`));
            const targetCapInt = parseInt(targetCapacityStr);
            const hasTargetCapacity = targetCapacityStr && !isNaN(targetCapInt);

            if (hasTargetCapacity) {
                const targetController = potentialDoorControllers.find(c => c.effectiveDoors === targetCapInt);
                if (targetController) {
                    if (allowFlexibilityFlag) {
                        // With flexibility enabled, use smart allocation strategy
                        console.log(`Target capacity ${targetCapInt} with flexibility enabled - using smart allocation`);
                        
                        const targetQty = Math.ceil(doorsToAllocate / targetCapInt);
                        const targetWaste = (targetQty * targetCapInt) - doorsToAllocate;
                        
                        console.log(`Target approach: ${targetQty} x ${targetCapInt}-door controllers, waste: ${targetWaste} doors`);
                        
                        // Smart flexibility algorithm
                        const smallerControllers = potentialDoorControllers
                            .filter(c => c.effectiveDoors < targetCapInt)
                            .sort((a, b) => a.effectiveDoors - b.effectiveDoors); // Sort smallest first
                        
                        if (smallerControllers.length > 0) {
                            console.log("Available smaller controllers:", smallerControllers.map(c => `${c.model}(${c.effectiveDoors})`));
                            
                            // Strategy: Use target controller first, then fill remainder efficiently
                            let remainingDoors = doorsToAllocate;
                            const allocation = {};
                            
                            // Step 1: Use target controller for as many full units as possible
                            const targetQty = Math.floor(remainingDoors / targetCapInt);
                            if (targetQty > 0) {
                                allocation[targetController.model] = targetQty;
                                remainingDoors -= targetQty * targetCapInt;
                                console.log(`Step 1: ${targetQty} x ${targetController.model}(${targetCapInt}), remaining: ${remainingDoors}`);
                            }
                            
                            // Step 2: Handle remaining doors with most efficient smaller controller
                            if (remainingDoors > 0) {
                                // Find the best fit controller for remaining doors
                                let bestController = null;
                                let bestWaste = Number.MAX_VALUE;
                                
                                for (const ctrl of smallerControllers) {
                                    const qty = Math.ceil(remainingDoors / ctrl.effectiveDoors);
                                    const waste = (qty * ctrl.effectiveDoors) - remainingDoors;
                                    
                                    if (waste < bestWaste) {
                                        bestController = ctrl;
                                        bestWaste = waste;
                                    }
                                }
                                
                                if (bestController) {
                                    const remainderQty = Math.ceil(remainingDoors / bestController.effectiveDoors);
                                    allocation[bestController.model] = (allocation[bestController.model] || 0) + remainderQty;
                                    console.log(`Step 2: ${remainderQty} x ${bestController.model}(${bestController.effectiveDoors}) for remaining ${remainingDoors} doors, waste: ${bestWaste}`);
                                }
                            }
                            
                            // Calculate total waste for comparison
                            let totalCapacity = 0;
                            let allocationSummary = [];
                            Object.entries(allocation).forEach(([model, qty]) => {
                                const controller = [...potentialDoorControllers, targetController].find(c => c.model === model);
                                const capacity = qty * controller.effectiveDoors;
                                totalCapacity += capacity;
                                allocationSummary.push(`${qty}x${controller.model}(${controller.effectiveDoors})`);
                            });
                            const flexWaste = totalCapacity - doorsToAllocate;
                            
                            console.log(`Flexible allocation: ${allocationSummary.join(' + ')}, total capacity: ${totalCapacity}, waste: ${flexWaste}`);
                            console.log(`Compare to target: ${targetQty + 1}x${targetController.model}(${targetCapInt}), waste: ${targetWaste}`);
                            
                            // Use flexible allocation if it's better
                            if (flexWaste < targetWaste) {
                                Object.entries(allocation).forEach(([model, qty]) => {
                                    C[model] = qty;
                                });
                                console.log(`Flexibility applied: Using flexible allocation (waste: ${flexWaste}) instead of target-only (waste: ${targetWaste})`);
                                doorsToAllocate = 0;
                            } else {
                                // Target-only is better or equal
                                const qty = Math.ceil(doorsToAllocate / targetCapInt);
                                C[targetController.model] = qty;
                                console.log(`Target-only is more efficient: Using ${qty} ${targetController.model} (waste: ${targetWaste}) vs flexible (waste: ${flexWaste})`);
                                doorsToAllocate = 0;
                            }
                        } else {
                            // No smaller controllers available
                            const qty = Math.ceil(doorsToAllocate / targetCapInt);
                            C[targetController.model] = qty;
                            console.log(`No smaller controllers available: Using target ${qty} ${targetController.model}`);
                            doorsToAllocate = 0;
                        }
                    } else {
                        // No flexibility - use target capacity exactly (stick to target size only)
                        const qty = Math.ceil(doorsToAllocate / targetCapInt);
                        C[targetController.model] = qty;
                        console.log(`No flexibility: Using target capacity exactly - ${qty} x ${targetController.model}(${targetCapInt}) = ${qty * targetCapInt} capacity for ${doorsToAllocate} doors`);
                        doorsToAllocate = 0;
                    }
                } else if (allowFlexibilityFlag) {
                    // Target controller not available but flexibility enabled
                    console.log(`Target capacity ${targetCapInt} not available, applying flexibility`);
                    
                    // Find controllers smaller than target that can work efficiently
                    const smallerControllers = potentialDoorControllers.filter(c => c.effectiveDoors < targetCapInt);
                    
                    if (smallerControllers.length > 0) {
                        // Use the largest available smaller controller
                        const flexController = smallerControllers[0]; // Already sorted by capacity
                        const qty = Math.ceil(doorsToAllocate / flexController.effectiveDoors);
                        C[flexController.model] = qty;
                        console.log(`Flexibility applied: Using ${qty} ${flexController.model} (capacity: ${flexController.effectiveDoors}) instead of target ${targetCapInt}`);
                        doorsToAllocate = 0;
                    } else {
                        // No smaller controllers available, use the smallest available
                        const fallbackController = potentialDoorControllers[potentialDoorControllers.length - 1];
                        const qty = Math.ceil(doorsToAllocate / fallbackController.effectiveDoors);
                        C[fallbackController.model] = qty;
                        console.log(`Flexibility fallback: Using ${qty} ${fallbackController.model}`);
                        doorsToAllocate = 0;
                    }
                } else {
                    console.log(`Target capacity ${targetCapInt} not found and flexibility disabled - using optimization`);
                    // Fall back to standard optimization when target not available and flexibility disabled
                }
            }
            
            // Step 5: Use optimized allocation strategy (only if doors still need allocation)
            if (doorsToAllocate > 0) {
                // IP communications requires special handling - minimize controller count
                if (comm === 'IP') {
                    // For IP, avoid using single-door controllers unless only a few doors remain
                    const highCapacityControllers = potentialDoorControllers.filter(c => c.effectiveDoors > 1);
                    const singleDoorControllers = potentialDoorControllers.filter(c => c.effectiveDoors === 1);
                    
                    // First allocate with high capacity controllers
                    if (highCapacityControllers.length > 0) {
                        const primaryController = highCapacityControllers[0]; // Use highest capacity first
                        const primaryCount = Math.floor(doorsToAllocate / primaryController.effectiveDoors);
                        
                        if (primaryCount > 0) {
                            C[primaryController.model] += primaryCount;
                            const doorsCovered = primaryCount * primaryController.effectiveDoors;
                            doorsToAllocate -= doorsCovered;
                            console.log(`IP optimization: Added ${primaryCount} ${primaryController.model} (covers ${doorsCovered} doors)`);
                        }
                    }
                    
                    // Handle remaining doors
                    if (doorsToAllocate > 0) {
                        // If 2 or fewer doors remain, use single-door controllers
                        if (doorsToAllocate <= 2 && singleDoorControllers.length > 0) {
                            C[singleDoorControllers[0].model] += doorsToAllocate;
                            console.log(`IP optimization: Added ${doorsToAllocate} ${singleDoorControllers[0].model} for remaining doors`);
                            doorsToAllocate = 0;
                        } 
                        // Otherwise, use one more high-capacity controller for efficiency
                        else if (highCapacityControllers.length > 0) {
                            // Find best fit controller for remaining doors
                            let bestController = highCapacityControllers[0];
                            let bestWaste = bestController.effectiveDoors - doorsToAllocate;
                            
                            for (const ctrl of highCapacityControllers) {
                                const waste = ctrl.effectiveDoors - doorsToAllocate;
                                if (waste >= 0 && waste < bestWaste) {
                                    bestController = ctrl;
                                    bestWaste = waste;
                                }
                            }
                            
                            C[bestController.model] += 1;
                            console.log(`IP optimization: Added 1 more ${bestController.model} for efficiency (covers last ${doorsToAllocate} doors with ${bestWaste} excess capacity)`);
                            doorsToAllocate = 0;
                        }
                    }
                } 
                // RS-485 or Mixed comms - optimize for efficient door allocation
                else {
                    // Try to optimize by using a mix of controllers
                    if (doorsToAllocate > potentialDoorControllers[0].effectiveDoors && potentialDoorControllers.length > 1) {
                        // Get the main high capacity controller
                        const highCapController = potentialDoorControllers[0];
                        // Use high capacity controllers for most doors
                        const highCapCount = Math.floor(doorsToAllocate / highCapController.effectiveDoors);
                        const doorsAfterHighCap = doorsToAllocate - (highCapCount * highCapController.effectiveDoors);
                        
                        console.log(`RS-485 optimization: First using ${highCapCount} ${highCapController.model}`);
                        console.log(`RS-485 optimization: Remaining doors after high capacity: ${doorsAfterHighCap}`);
                        
                        if (doorsAfterHighCap > 0) {
                            // Find the most efficient controller for remaining doors
                            let bestController = null;
                            let bestWaste = Number.MAX_VALUE;
                            
                            for (const ctrl of potentialDoorControllers) {
                                if (ctrl.model !== highCapController.model) {
                                    const ctrlWaste = ctrl.effectiveDoors - doorsAfterHighCap;
                                    // We prefer controllers that have just enough capacity or slightly more
                                    if (ctrlWaste >= 0 && ctrlWaste < bestWaste) {
                                        bestController = ctrl;
                                        bestWaste = ctrlWaste;
                                    }
                                }
                            }
                            
                            // If no good fit, fall back to the smallest controller that covers needs
                            if (!bestController) {
                                bestController = [...potentialDoorControllers]
                                    .filter(c => c.effectiveDoors >= doorsAfterHighCap)
                                    .sort((a, b) => a.effectiveDoors - b.effectiveDoors)[0];
                                    
                                if (!bestController) {
                                    bestController = potentialDoorControllers[potentialDoorControllers.length - 1]; // Smallest available
                                }
                            }
                            
                            if (bestController) {
                                // Apply the optimization
                                C[highCapController.model] += highCapCount;
                                C[bestController.model] += 1;
                                
                                console.log(`RS-485 optimization: Using ${highCapCount} ${highCapController.model} + 1 ${bestController.model}`);
                                doorsToAllocate = 0;
                            }
                        } else {
                            // If high capacity controllers fit perfectly
                            C[highCapController.model] += highCapCount;
                            console.log(`RS-485 optimization: Perfect fit with ${highCapCount} ${highCapController.model}`);
                            doorsToAllocate = 0;
                        }
                    }
                    
                    // If we still have doors to allocate (no optimization found), use standard approach
                    if (doorsToAllocate > 0) {
                        for (const controller of potentialDoorControllers) {
                            const qty = Math.ceil(doorsToAllocate / controller.effectiveDoors);
                            if (qty > 0) {
                                C[controller.model] += qty;
                                console.log(`Standard allocation: Added ${qty} ${controller.model}`);
                                doorsToAllocate = 0;
                                break; // Only use one controller type for standard allocation
                            }
                        }
                    }
                }
            }
        }
        
        // Step 6: Check for SynOne-only scenario
        const doorCtrlModelsUsed = Object.keys(C).filter(m => m !== 'SynApp' && m !== 'SynIO' && C[m] > 0);
        const synOneDataInThisConfig = availableData.find(d => d.model === 'SynOne');
        if (doorCtrlModelsUsed.length === 1 && doorCtrlModelsUsed[0] === 'SynOne' && synOneDataInThisConfig && !synOneDataInThisConfig.requiresSynAppInitially) {
            isSynOneOnlyScenario = true;
            console.log('SynOne-only scenario detected');
        }
        
        // Finalize SynApp count based on connectivity needs
        finalizeSynAppCount(C, rIn + rOut, isSynOneOnlyScenario);
        
        // Calculate SynIO modules needed for additional I/O
        calculateSynIO(C, requiredInputs, requiredOutputs, excludeSynAppDoorFlag);
        
        console.log('Final controller counts:', Object.entries(C).filter(([_, v]) => v > 0).map(([k, v]) => `${k}: ${v}`).join(', '));
        return C;
    }

    function finalizeSynAppCount(currentCounts, totalRequiredReaders, isSynOneOnly) {
        if (isSynOneOnly) {
            currentCounts.SynApp = 0;
            return;
        }
        const depModels = availableControllerData.filter(c => c.requiresSynAppInitially).map(c => c.model);
        let depCount = 0;
        depModels.forEach(m => {
            if (m !== 'SynApp') {
                depCount += currentCounts[m] || 0;
            }
        });
        const neededByCtrl = depCount > 0 ? Math.ceil(depCount / SYNAPP_MAX_DOOR_CONTROLLERS) : 0;
        const neededByRdr = totalRequiredReaders > 0 ? Math.ceil(totalRequiredReaders / SYNAPP_MAX_READERS) : 0;
        const initSynApp = currentCounts.SynApp > 0 ? 1 : 0;
        currentCounts.SynApp = Math.max(neededByCtrl, neededByRdr, initSynApp);
    }

    function calculateSynIO(currentCounts, requiredInputs, requiredOutputs, excludeSynAppDoorFlag) {
        let provI = 0;
        let provO = 0;
        CONTROLLERS.forEach(ci => {
            if (ci.model !== "SynIO") {
                const qty = currentCounts[ci.model] || 0;
                if (qty > 0) {
                    const isEx = ci.model === 'SynApp' && excludeSynAppDoorFlag;
                    const i2a = isEx ? 0 : (ci.baseInputs ?? 0);
                    const o2a = isEx ? 0 : (ci.baseOutputs ?? 0);
                    provI += qty * i2a;
                    provO += qty * o2a;
                }
            }
        });
        const iDef = Math.max(0, requiredInputs - provI);
        const oDef = Math.max(0, requiredOutputs - provO);
        if (iDef > 0 || oDef > 0) {
            const ioInfo = findControllerInfo("SynIO");
            const iPer = ioInfo?.baseInputs || 16;
            const oPer = ioInfo?.baseOutputs || 16;
            const ioNeededI = (iPer > 0) ? Math.ceil(iDef / iPer) : 0;
            const ioNeededO = (oPer > 0) ? Math.ceil(oDef / oPer) : 0;
            currentCounts.SynIO = Math.max(ioNeededI, ioNeededO);
        } else {
            currentCounts.SynIO = 0;
        }
    }

    const calculateTotalForType = (items, type) => {
        if (!Array.isArray(items)) {
            console.error("calculateTotalForType received non-array:", items);
            return '0.00';
        }
        return items.reduce((total, item) => {
            if (item && typeof item === 'object' && item.costType === type) {
                const msrp = item.msrp ?? 0;
                const discount = item.discountStandard ?? 0;
                const quantity = item.qty ?? 0;
                if (typeof msrp === 'number' && typeof discount === 'number' && typeof quantity === 'number') {
                    const lineTotal = msrp * (1 - discount / 100) * quantity;
                    return total + lineTotal;
                } else {
                    console.warn("Invalid item data for total calculation:", item);
                    return total;
                }
            }
            return total;
        }, 0).toFixed(2);
    };

    function handleSave() {
        const systemCurrency = getCurrentSystemCurrency();
        
        if (!name.trim()) {
            alert("Please enter a project name.");
            return;
        }
        if (!protocol || !deployment || !commsType) {
            alert("Please complete all System Configuration selections.");
            return;
        }
        if (!systemType) {
            alert("Please select a System Type.");
            return;
        }
        if (systemUsers <= 0) {
            alert("Please enter the number of System Users (> 0).");
            return;
        }
        if (doors <= 0 && reqInputs <= 0 && reqOutputs <= 0 && Object.values(ctrls).every(qty => qty === 0)) {
            alert("Please specify requirements (Doors, Inputs, Outputs) or System Users (> 0).");
            return;
        }
        if (calculatedQuoteItems.length === 0 && (doors > 0 || reqInputs > 0 || reqOutputs > 0 || systemUsers > 0)) {
            alert("Calculation resulted in no quote items despite requirements. Please check configuration or product data availability.");
            return;
        }
        if (calculatedQuoteItems.length === 0) {
            alert("No items to save in the quote.");
            return;
        }

        const finalItems = calculatedQuoteItems.map(item => ({
            articleNumber: item.articleNumber || '',
            model: item.model || '',
            description: item.description || '',
            method: item.method || 'Upfront',
            msrpGBP: item.msrpGBP ?? 0,
            msrp: item.msrp ?? 0,
            discountStandard: item.discountStandard ?? 0,
            qty: item.qty ?? 0,
            costType: item.costType || 'One-Off',
            smc: item.smc ?? 0,
        }));

        const smcCostValue = finalItems.reduce((total, item) => {
            if (item.costType === 'One-Off' && item.smc > 0) {
                const msrp = item.msrp ?? 0;
                const discount = item.discountStandard ?? 0;
                const quantity = item.qty ?? 0;
                if (typeof msrp === 'number' && typeof discount === 'number' && typeof quantity === 'number' && typeof item.smc === 'number') {
                    const netPrice = msrp * (1 - discount / 100) * quantity;
                    const smcValueForItem = netPrice * (item.smc / 100);
                    return total + smcValueForItem;
                }
            }
            return total;
        }, 0);

        const quoteObject = {
            id: String(Date.now()),
            name: name.trim(),
            created: new Date().toISOString(),
            status: "Quick Config",
            company: currentUser?.company || "N/A",
            items: finalItems,
            systemDetails: {
                protocol,
                deployment,
                commsType,
                targetDoorsPerController: targetDoorsPerController || "Default",
                allowFlexibility: allowFlexibility || false, // Add this to saved details
                doors,
                readersIn,
                readersOut,
                reqInputs,
                reqOutputs,
                excludeSynAppDoor,
                systemType,
                systemUsers,
                softwareSelections: softwareSelections || {}
            },
            projectType: systemType,
            totalOneOff: calculateTotalForType(finalItems, 'One-Off'),
            totalMonthly: calculateTotalForType(finalItems, 'Monthly'),
            smcCost: systemType === 'On-Prem' ? smcCostValue.toFixed(2) : '0.00',
            currency: systemCurrency.code,
            currencySymbol: systemCurrency.symbol,
            approvalStatus: "Pending",
            client: client || "N/A",
            date: date || new Date().toISOString().slice(0, 10),
            notes: notes || "",
        };

        try {
            if (typeof addQuote === 'function') {
                console.log("Saving quote:", quoteObject);
                addQuote(quoteObject);
                alert(`Quote "${quoteObject.name}" saved successfully!`);
                navigate("/");
            } else {
                console.error("Error: addQuote is not a function.");
                alert("Error: Could not save quote (addQuote not available).");
            }
        } catch (error) {
            console.error("Error saving quote:", error);
            alert(`Failed to save quote. Error: ${error.message}`);
        }
    }

    const handleConfigModalOpen = () => {
        if (!protocol || !deployment || !commsType || availableTargetCapacities.length === 0) {
            alert("Please complete all system configuration selections before adjusting.");
            return;
        }
        setShowConfigModal(true);
    };

    return (
        <div className="quick-config-page">
            <div
                className="header-bar"
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 20px",
                    width: "100%",
                    boxSizing: "border-box",
                    border: "2px solid #007bff",
                    boxShadow: "0 0 3px #FFD700",
                }}
            >
                <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
                    <img
                        src="/assets/synguard-logo.png"
                        alt="Synguard Logo"
                        style={{ height: "40px" }}
                    />
                    <div style={{ fontSize: "1.2em", color: "#495057" }}>Quick Quote</div>
                </div>
            </div>
            <div style={{ display: "flex", gap: "20px", padding: "0 20px", flexWrap: "wrap" }}>
                <div
                    className="inputs-panel panel"
                    style={{
                        flex: "1 1 400px",
                        minWidth: "350px",
                        border: "2px solid #007bff",
                        boxShadow: "0 0 3px #FFD700",
                    }}
                >
                    <h3>Requirements</h3>
                    <div style={{ display: "flex", gap: "10px", marginBottom: "15px" }}>
                        <button
                            className="action-btn"
                            onClick={handleConfigModalOpen}
                            style={{ backgroundColor: "#007bff", color: "white" }}
                        >
                            Adjust System Configuration
                        </button>
                        <button
                            className="action-btn"
                            onClick={() => setShowSoftwareModal(true)}
                            style={{ backgroundColor: "#007bff", color: "white" }}
                        >
                            Select Software
                        </button>
                        <button
                            className="action-btn"
                            onClick={() => setShowControllerModal(true)}
                            style={{ backgroundColor: "#007bff", color: "white" }}
                        >
                            Select Controllers
                        </button>
                    </div>
                    <div className="config-box">
                        <label>
                            System Users <span style={{ color: "#dc3545" }}>*</span>
                            <input
                                type="number"
                                min="1"
                                name="systemUsers"
                                value={systemUsers}
                                onChange={handleNumberChange("systemUsers")}
                                placeholder="Enter number of users (min 1)"
                                required
                            />
                        </label>
                        
                        {/* NEW TARGET DOORS SELECTION */}
                        <label>
                            Target Doors per Controller
                            <select
                                name="targetDoorsPerController"
                                value={targetDoorsPerController}
                                onChange={(e) => updateConfigState({ targetDoorsPerController: e.target.value })}
                                disabled={!protocol || !deployment || !commsType || availableTargetCapacities.length === 0}
                                title={!protocol || !deployment || !commsType 
                                    ? "Complete System Configuration first" 
                                    : availableTargetCapacities.length === 0
                                    ? "No valid controller options for current configuration"
                                    : "Set the number of doors required per controller. This is a system wide setting, to specify custom controllers use the Advanced Quote tool."
                                }
                            >
                                <option value="">Auto (Optimize)</option>
                                {availableTargetCapacities.map(capacity => (
                                    <option key={capacity.value} value={capacity.value}>
                                        {capacity.label}
                                    </option>
                                ))}
                            </select>
                            <small style={{ display: "block", marginTop: "5px", color: "#6c757d", fontSize: "12px" }}>
                                Set the number of doors required per controller. This is a system wide setting, 
                                to specify custom controllers use the Advanced Quote tool.
                                {protocol === "Wiegand" && deployment === "In & Out" && 
                                    " Note: Wiegand In&Out requires 1 controller per door."}
                            </small>
                        </label>

                        {/* NEW FLEXIBILITY OPTION */}
                        <label style={{ display: "flex", alignItems: "center", marginTop: "10px" }}>
                            <input
                                type="checkbox"
                                name="allowFlexibility"
                                checked={allowFlexibility || false}
                                onChange={(e) => updateConfigState({ allowFlexibility: e.target.checked })}
                                style={{ marginRight: "8px" }}
                                disabled={!targetDoorsPerController}
                                title={!targetDoorsPerController 
                                    ? "Select a target doors per controller first" 
                                    : "Allow deviation from target doors per controller to create the most efficient system design, whilst not moving away from the required comms type."
                                }
                            />
                            Flexibility: Smaller controllers
                            <small style={{ display: "block", marginTop: "5px", color: "#6c757d", fontSize: "12px", marginLeft: "20px" }}>
                                Allow deviation from target doors per controller to create the most efficient system design, 
                                whilst not moving away from the required comms type.
                            </small>
                        </label>

                        <hr style={{ margin: "15px 0", borderColor: "#007bff" }} />
                        
                        <label>
                            Doors
                            <input
                                type="number"
                                min="0"
                                name="doors"
                                value={doors}
                                onChange={handleNumberChange("doors")}
                            />
                        </label>
                        <label style={{ display: "flex", alignItems: "center", marginTop: "10px" }}>
                            <input
                                type="checkbox"
                                name="excludeSynAppDoor"
                                checked={excludeSynAppDoor}
                                onChange={handleExcludeSynAppChange}
                                style={{ marginRight: "8px" }}
                            />
                            Exclude SynApp Door
                        </label>
                        <label>
                            In Readers <small>(Equals Doors)</small>
                            <input
                                type="number"
                                min="0"
                                value={readersIn}
                                readOnly
                                className="readonly-input"
                            />
                        </label>
                        <label>
                            Out Readers <small>(No. of Doors needing Out)</small>
                            <input
                                type="number"
                                min="0"
                                max={doors}
                                name="readersOut"
                                value={readersOut}
                                onChange={handleNumberChange("readersOut")}
                                disabled={deployment === "In Only"}
                                style={{
                                    backgroundColor: deployment === "In Only" ? "#e9ecef" : "white",
                                    cursor: deployment === "In Only" ? "not-allowed" : "text",
                                }}
                                title={
                                    deployment === "In Only"
                                        ? "Out readers disabled for this configuration"
                                        : "Enter number of out readers"
                                }
                            />
                        </label>
                        <label>
                            Additional Inputs <small>(Beyond door sensors/REX)</small>
                            <input
                                type="number"
                                min="0"
                                name="reqInputs"
                                value={reqInputs}
                                onChange={handleNumberChange("reqInputs")}
                            />
                        </label>
                        <label>
                            Additional Outputs <small>(Beyond lock relays)</small>
                            <input
                                type="number"
                                min="0"
                                name="reqOutputs"
                                value={reqOutputs}
                                onChange={handleNumberChange("reqOutputs")}
                            />
                        </label>
                    </div>
                </div>
                <div
                    className="overview-panel panel"
                    style={{
                        flex: "1 1 400px",
                        minWidth: "350px",
                        border: "2px solid #007bff",
                        boxShadow: "0 0 3px #FFD700",
                    }}
                >
                    <h3>System Overview</h3>
                    {protocol && deployment && commsType && systemType ? (
                        <p className="config-summary">
                            <strong>Config:</strong> {systemType} | {protocol} | {deployment} | {commsType}
                            {targetDoorsPerController && ` | Target: ${targetDoorsPerController} Doors`}
                            {allowFlexibility && " | Flex Enabled"}
                            {excludeSynAppDoor && " | Excl. SynApp"}
                        </p>
                    ) : (
                        <p style={{ fontSize: "0.9em", color: "#777", fontStyle: "italic" }}>
                            Complete System Configuration selections to calculate.
                        </p>
                    )}
                    <h4>Resource Summary</h4>
                    <table className="overview-table">
                        <thead>
                            <tr>
                                <th>Resource</th>
                                <th>Required</th>
                                <th>Provided {excludeSynAppDoor && <small>(Excl. SynApp)</small>}</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Users</td>
                                <td>{systemUsers}</td>
                                <td>{systemUsers > 0 ? "Licensing Added" : "-"}</td>
                            </tr>
                            <tr>
                                <td>Doors</td>
                                <td>{doors}</td>
                                <td
                                    style={{
                                        color: totalProvidedDoors < doors ? "#dc3545" : "#28a745",
                                        fontWeight: totalProvidedDoors < doors ? "bold" : "normal",
                                    }}
                                >
                                    {totalProvidedDoors}
                                </td>
                            </tr>
                            {protocol === "Wiegand" ? (
                                <>
                                    <tr>
                                        <td>Wiegand Readers (In)</td>
                                        <td>{readersIn}</td>
                                        <td
                                            style={{
                                                color: totalProvidedReaders < readersIn ? "#dc3545" : "#28a745",
                                                fontWeight: totalProvidedReaders < readersIn ? "bold" : "normal",
                                            }}
                                        >
                                            {totalProvidedReaders}
                                        </td>
                                    </tr>
                                    {readersOut > 0 && (
                                        <tr>
                                            <td>Wiegand Readers (Out)</td>
                                            <td>{readersOut}</td>
                                            <td
                                                style={{
                                                    color: totalProvidedReaders < totalReqReaders ? "#dc3545" : "#28a745",
                                                    fontWeight: totalProvidedReaders < totalReqReaders ? "bold" : "normal",
                                                }}
                                            >
                                                {totalProvidedReaders} <small>(Pairs)</small>
                                            </td>
                                        </tr>
                                    )}
                                </>
                            ) : protocol === "OSDP" ? (
                                <tr>
                                    <td>OSDP Readers</td>
                                    <td>{totalReqReaders}</td>
                                    <td
                                        style={{
                                            color: totalProvidedReaders < totalReqReaders ? "#dc3545" : "#28a745",
                                            fontWeight: totalProvidedReaders < totalReqReaders ? "bold" : "normal",
                                        }}
                                    >
                                        {totalProvidedReaders}
                                    </td>
                                </tr>
                            ) : (
                                <tr>
                                    <td>Readers</td>
                                    <td>{totalReqReaders > 0 ? totalReqReaders : "-"}</td>
                                    <td>-</td>
                                </tr>
                            )}
                            <tr>
                                <td>Inputs</td>
                                <td>{reqInputs}</td>
                                <td
                                    style={{
                                        color: totalProvidedInputs < reqInputs ? "#dc3545" : "#28a745",
                                        fontWeight: totalProvidedInputs < reqInputs ? "bold" : "normal",
                                    }}
                                >
                                    {totalProvidedInputs}
                                </td>
                            </tr>
                            <tr>
                                <td>Outputs</td>
                                <td>{reqOutputs}</td>
                                <td
                                    style={{
                                        color: totalProvidedOutputs < reqOutputs ? "#dc3545" : "#28a745",
                                        fontWeight: totalProvidedOutputs < reqOutputs ? "bold" : "normal",
                                    }}
                                >
                                    {totalProvidedOutputs}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <h4>Calculated Hardware</h4>
                    <ul className="controller-summary-list">
                        {Object.entries(ctrls)
                            .filter(([_, qty]) => qty > 0)
                            .sort((a, b) => {
                                if (a[0] === "SynApp") return -1;
                                if (b[0] === "SynApp") return 1;
                                if (a[0] === "SynIO") return 1;
                                if (b[0] === "SynIO") return -1;
                                return a[0].localeCompare(b[0]);
                            })
                            .map(([model, qty]) => (
                                <li key={model}>
                                    {findControllerInfo(model)?.description || model}: <strong>{qty}</strong>
                                </li>
                            ))}
                        {Object.entries(ctrls).filter(([_, q]) => q > 0).length === 0 && (
                            protocol &&
                            deployment &&
                            commsType &&
                            (doors > 0 || reqInputs > 0 || reqOutputs > 0) ? (
                                <li>Calculating...</li>
                            ) : (
                                <li>(Complete configuration and requirements)</li>
                            )
                        )}
                    </ul>
                </div>
            </div>
            <div
                className="quote-preview-section panel"
                style={{
                    margin: "20px",
                    border: "2px solid #007bff",
                    boxShadow: "0 0 3px #FFD700",
                }}
            >
                <h3>Quote Preview</h3>
                {productsLoading && <p>Loading product details...</p>}
                {!productsLoading && calculatedQuoteItems.length === 0 && (
                    <p style={{ fontStyle: "italic", color: "#6c757d" }}>
                        Complete configuration and requirements above to generate quote items.
                    </p>
                )}
                {!productsLoading && calculatedQuoteItems.length > 0 && (
                    <table className="quote-preview-table">
                        <thead>
                            <tr>
                                <th>Article No.</th>
                                <th>Model</th>
                                <th>Description</th>
                                <th>Cost Type</th>
                                <th>Qty</th>
                                <th>MSRP ({getCurrentSystemCurrency().code})</th>
                                <th>Line Total ({getCurrentSystemCurrency().code})</th>
                            </tr>
                        </thead>
                        <tbody>
                            {calculatedQuoteItems.map((item, index) => (
                                <tr key={item.articleNumber || `${item.model}-${index}`}>
                                    <td>{item.articleNumber}</td>
                                    <td>{item.model}</td>
                                    <td>{item.description}</td>
                                    <td>{item.costType}</td>
                                    <td style={{ textAlign: "center" }}>{item.qty}</td>
                                    <td>{getCurrentSystemCurrency().symbol}{(item.msrp ?? 0).toFixed(2)}</td>
                                    <td>{getCurrentSystemCurrency().symbol}{((item.msrp ?? 0) * (1 - (item.discountStandard ?? 0) / 100) * (item.qty ?? 0)).toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
            <div className="floating-save">
                <button
                    className="action-btn"
                    onClick={handleSave}
                    disabled={
                        !name ||
                        !protocol ||
                        !deployment ||
                        !commsType ||
                        !systemType ||
                        systemUsers <= 0
                    }
                    style={{ backgroundColor: "#007bff", color: "white" }}
                    title={
                        !name ||
                        !protocol ||
                        !deployment ||
                        !commsType ||
                        !systemType ||
                        systemUsers <= 0
                            ? "Please complete all required fields"
                            : "Save Quote"
                    }
                >
                    💾 Save Quote
                </button>
                <button
                    className="action-btn"
                    onClick={() => navigate("/")}
                    style={{ backgroundColor: "#6c757d", color: "white" }}
                >
                    Back
                </button>
            </div>
            {showSoftwareModal && (
                <SoftwareModal
                    isCloud={systemType === "Cloud"}
                    initialSelections={softwareSelections || {}}
                    onSave={handleSoftwareSave}
                    onClose={() => setShowSoftwareModal(false)}
                />
            )}
            {showControllerModal && (
                <ControllerSelectionModal
                    initialSelections={ctrls}
                    onSave={handleControllerSave}
                    onClose={() => setShowControllerModal(false)}
                />
            )}
            {showConfigModal && (
                <ConfigModal
                    initial={{
                        protocol: protocol,
                        doorComms: commsType,
                        deployment: deployment === "In" ? "In Only" : "In & Out",
                        targetDoorsPerController: targetDoorsPerController,
                        cloudMode: systemType.toLowerCase(),
                    }}
                    doorCountOptions={availableTargetCapacities}
                    onSave={handleConfigSave}
                    onClose={() => setShowConfigModal(false)}
                />
            )}
        </div>
    );
}